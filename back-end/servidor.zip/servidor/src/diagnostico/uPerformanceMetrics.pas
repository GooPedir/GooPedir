unit uPerformanceMetrics;

interface

uses
  Horse;

procedure PerformanceMetricsMiddleware(Req: THorseRequest; Res: THorseResponse;
  Next: TProc);
procedure PerformanceSQL(const SQLHash, SQLText: string; DurationMS: UInt64;
  Rows: Integer; Success: Boolean; const ErrorMessage: string = '');
procedure PerformanceJSON(DurationMS: UInt64; Rows: Integer; Bytes: Integer);
procedure PerformanceStep(const StepName: string; DurationMS: Int64);
procedure PerformanceStatusField(const FieldName: string; Bytes: Integer);
procedure PerformanceParamSlow(const Parametro: string; DurationMS: Int64);
procedure PerformanceSyncMesas(Empresa: Integer; ClientVersion,
  ServerVersion: Int64; Changed: Boolean; VersionQueryMS, DataQueryMS,
  SerializeMS: Int64; Bytes: Integer; TotalMS: Int64);

implementation

uses
  Winapi.Windows, System.SysUtils, System.Classes, System.IOUtils,
  System.SyncObjs;

type
  TRequestMetrics = record
    Active: Boolean;
    RequestId: string;
    Metodo: string;
    Endpoint: string;
    Inicio: UInt64;
    TempoSQLMS: UInt64;
    TempoJSONMS: UInt64;
    QuantidadeQueries: Integer;
    QuantidadeLinhas: Integer;
    TamanhoRespostaBytes: Integer;
    StatusHTTP: Integer;
    Erro: string;
  end;

threadvar
  CurrentMetrics: TRequestMetrics;

var
  LogLock: TCriticalSection;
  RequestCounter: Int64;

function MetricsEnabled: Boolean;
begin
  Result := not SameText(GetEnvironmentVariable('GOOPEDIR_PERFORMANCE'), '0');
end;

function LogDirectory: string;
begin
  Result := TPath.Combine(ExtractFilePath(ParamStr(0)), 'log\performance');
end;

function Sanitize(const Value: string; MaxLen: Integer): string;
begin
  Result := StringReplace(Value, sLineBreak, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #13, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #10, ' ', [rfReplaceAll]);
  Result := StringReplace(Result, #9, ' ', [rfReplaceAll]);
  Result := Trim(Result);
  if Length(Result) > MaxLen then
    Result := Copy(Result, 1, MaxLen) + '...';
end;

function NextRequestId: string;
begin
  Result := FormatDateTime('yyyymmddhhnnsszzz', Now) + '-' +
    TInterlocked.Increment(RequestCounter).ToString;
end;

procedure AppendLog(const Line: string);
var
  FileName: string;
begin
  if not MetricsEnabled then
    Exit;

  ForceDirectories(LogDirectory);
  FileName := TPath.Combine(LogDirectory,
    FormatDateTime('yyyy-mm-dd', Date) + '.log');

  LogLock.Acquire;
  try
    TFile.AppendAllText(FileName, Line + sLineBreak, TEncoding.UTF8);
  finally
    LogLock.Release;
  end;
end;

procedure ClearCurrentMetrics;
begin
  CurrentMetrics.Active := False;
  CurrentMetrics.RequestId := '';
  CurrentMetrics.Metodo := '';
  CurrentMetrics.Endpoint := '';
  CurrentMetrics.Inicio := 0;
  CurrentMetrics.TempoSQLMS := 0;
  CurrentMetrics.TempoJSONMS := 0;
  CurrentMetrics.QuantidadeQueries := 0;
  CurrentMetrics.QuantidadeLinhas := 0;
  CurrentMetrics.TamanhoRespostaBytes := 0;
  CurrentMetrics.StatusHTTP := 0;
  CurrentMetrics.Erro := '';
end;

procedure PerformanceSQL(const SQLHash, SQLText: string; DurationMS: UInt64;
  Rows: Integer; Success: Boolean; const ErrorMessage: string);
var
  Line: string;
begin
  if not CurrentMetrics.Active then
    Exit;

  Inc(CurrentMetrics.QuantidadeQueries);
  Inc(CurrentMetrics.QuantidadeLinhas, Rows);
  Inc(CurrentMetrics.TempoSQLMS, DurationMS);

  if (DurationMS >= 300) or (not Success) then
  begin
    Line := Format('[SLOW_SQL] request_id=%s endpoint=%s duration_ms=%d rows=%d sql_hash=%s success=%s sql="%s" error="%s"',
      [CurrentMetrics.RequestId, CurrentMetrics.Endpoint, DurationMS, Rows,
       SQLHash, BoolToStr(Success, True), Sanitize(SQLText, 500),
       Sanitize(ErrorMessage, 300)]);
    AppendLog(Line);
  end;
end;

procedure PerformanceJSON(DurationMS: UInt64; Rows: Integer; Bytes: Integer);
begin
  if not CurrentMetrics.Active then
    Exit;

  Inc(CurrentMetrics.TempoJSONMS, DurationMS);
  if Bytes > CurrentMetrics.TamanhoRespostaBytes then
    CurrentMetrics.TamanhoRespostaBytes := Bytes;
end;

procedure PerformanceStep(const StepName: string; DurationMS: Int64);
begin
  if not CurrentMetrics.Active then
    Exit;

  AppendLog(Format('[STEP] request_id=%s endpoint=%s step=%s duration_ms=%d',
    [CurrentMetrics.RequestId, CurrentMetrics.Endpoint,
     Sanitize(StepName, 100), DurationMS]));
end;

procedure PerformanceStatusField(const FieldName: string; Bytes: Integer);
begin
  if not CurrentMetrics.Active then
    Exit;

  AppendLog(Format('[STATUS_FIELD] request_id=%s field=%s bytes=%d',
    [CurrentMetrics.RequestId, Sanitize(FieldName, 100), Bytes]));
end;

procedure PerformanceParamSlow(const Parametro: string; DurationMS: Int64);
begin
  if not CurrentMetrics.Active then
    Exit;

  AppendLog(Format('[PARAM_SLOW] request_id=%s parametro=%s duration_ms=%d',
    [CurrentMetrics.RequestId, Sanitize(Parametro, 150), DurationMS]));
end;

procedure PerformanceSyncMesas(Empresa: Integer; ClientVersion,
  ServerVersion: Int64; Changed: Boolean; VersionQueryMS, DataQueryMS,
  SerializeMS: Int64; Bytes: Integer; TotalMS: Int64);
begin
  if not CurrentMetrics.Active then
    Exit;

  AppendLog(Format('[SYNC_MESAS] request_id=%s empresa=%d client_version=%d server_version=%d changed=%s version_query_ms=%d data_query_ms=%d serialize_ms=%d bytes=%d total_ms=%d',
    [CurrentMetrics.RequestId, Empresa, ClientVersion, ServerVersion,
     BoolToStr(Changed, True), VersionQueryMS, DataQueryMS, SerializeMS,
     Bytes, TotalMS]));
end;

procedure PerformanceMetricsMiddleware(Req: THorseRequest; Res: THorseResponse;
  Next: TProc);
var
  TempoTotal: UInt64;
  ResponseText: string;
begin
  if not MetricsEnabled then
  begin
    Next;
    Exit;
  end;

  ClearCurrentMetrics;
  CurrentMetrics.Active := True;
  CurrentMetrics.RequestId := NextRequestId;
  CurrentMetrics.Metodo := Req.RawWebRequest.Method;
  CurrentMetrics.Endpoint := Req.RawWebRequest.RawPathInfo;
  CurrentMetrics.Inicio := GetTickCount64;

  try
    try
      Next;
    except
      on E: Exception do
      begin
        CurrentMetrics.Erro := Sanitize(E.ClassName + ': ' + E.Message, 300);
        raise;
      end;
    end;
  finally
    TempoTotal := GetTickCount64 - CurrentMetrics.Inicio;
    CurrentMetrics.StatusHTTP := Res.Status;
    try
      ResponseText := Res.RawWebResponse.Content;
      CurrentMetrics.TamanhoRespostaBytes := Length(TEncoding.UTF8.GetBytes(ResponseText));
    except
    end;
    if (CurrentMetrics.StatusHTTP >= 500) and (CurrentMetrics.Erro = '') then
      CurrentMetrics.Erro := Sanitize(Res.RawWebResponse.Content, 300);

    AppendLog(Format('[REQUEST] request_id=%s method=%s endpoint=%s status=%d total_ms=%d sql_ms=%d json_ms=%d queries=%d rows=%d bytes=%d error="%s"',
      [CurrentMetrics.RequestId, CurrentMetrics.Metodo,
       Sanitize(CurrentMetrics.Endpoint, 500), CurrentMetrics.StatusHTTP,
       TempoTotal, CurrentMetrics.TempoSQLMS, CurrentMetrics.TempoJSONMS,
       CurrentMetrics.QuantidadeQueries, CurrentMetrics.QuantidadeLinhas,
       CurrentMetrics.TamanhoRespostaBytes, CurrentMetrics.Erro]));
    ClearCurrentMetrics;
  end;
end;

initialization
  LogLock := TCriticalSection.Create;

finalization
  LogLock.Free;

end.
