unit uFilaImpressao;

interface

function EnfileirarImpressaoGo(Codigo: Integer; const Tipo: string = 'PRODUTO')
  : Boolean;

implementation

uses
  System.SysUtils, System.Classes, System.SyncObjs, System.Generics.Collections,
  uMain, uPerformanceMetrics;

var
  FilaImpressaoLock: TCriticalSection;
  FilaImpressaoChaves: TDictionary<string, TDateTime>;

function ChaveImpressao(Codigo: Integer; const Tipo: string): string;
begin
  Result := UpperCase(Trim(Tipo)) + ':' + Codigo.ToString;
end;

procedure RemoverChaveImpressao(const Chave: string);
begin
  FilaImpressaoLock.Acquire;
  try
    FilaImpressaoChaves.Remove(Chave);
  finally
    FilaImpressaoLock.Release;
  end;
end;

function EnfileirarImpressaoGo(Codigo: Integer; const Tipo: string): Boolean;
var
  Chave: string;
begin
  Result := False;
  Chave := ChaveImpressao(Codigo, Tipo);

  FilaImpressaoLock.Acquire;
  try
    if FilaImpressaoChaves.ContainsKey(Chave) then
    begin
      PerformanceStep('impressao_duplicada', 0);
      Exit;
    end;

    FilaImpressaoChaves.Add(Chave, Now);
    Result := True;
  finally
    FilaImpressaoLock.Release;
  end;

  TThread.CreateAnonymousThread(
    procedure
    begin
      try
        frmServidor.enviarImpressaoGo(Codigo);
      except
        on E: Exception do
          PerformanceStep('impressao_worker_erro', 0);
      end;
      RemoverChaveImpressao(Chave);
    end).Start;
end;

initialization
  FilaImpressaoLock := TCriticalSection.Create;
  FilaImpressaoChaves := TDictionary<string, TDateTime>.Create;

finalization
  FilaImpressaoChaves.Free;
  FilaImpressaoLock.Free;

end.
