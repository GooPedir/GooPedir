unit uImportacaoPedio;

interface

uses uRequisicao, System.JSON, System.SysUtils, Conexao, DataSet.Serialize,
  System.Generics.Collections, System.StrUtils, System.Classes, uGlobais,
  dialogs, uImportaProduto;

type
  TGetPedidoThread = class(TThread)
  private
    FID: string; // Armazena o ID do pedido
  protected
    procedure Execute; override; // M�todo principal da thread
  public
    constructor Create(const AID: string); // Construtor para passar o ID
  end;

  TCliente = record
    Nome: string;
    Celular: string;
    CPF: string;
    Nascimento: string;
    Codigo: Integer;
    Mesa: Integer;
    PedidoMesa: Integer;
  end;

  TEndereco = record
    Rua: string;
    Numero: string;
    Bairro: string;
    Cidade: string;
    Estado: string;
    Complemento: string;
    Codigo: Integer;
  end;

  TExtra = record
    Categoria: String;
    Descricao: String;
    Valor: Real;
    Quantidade: Real;
    Codigo: Integer;
  end;

  TProduto = record
    ID: string;
    Nome: string;
    Preco: Double;
    Unitario: Real;
    ValorExtra: Real;
    Quantidade: Integer;
    CodigoProduto: Integer;
    Codigo: Integer;
    Extra: TArray<TExtra>;

  end;

  TPagamento = record
    Descricao: string;
    Codigo: Integer;
    MP: String;
    Transacao: String;
  end;

  TPedido = record
    Codigo: Integer;
    CodigoDia: Integer;
    ID: string;
    Data: TDateTime;
    SubTotal: Double;
    Desconto: Double;
    Taxa: Double;
    Total: Double;
    URL: string;
    Partner: string;
    Cupom: string;
    Latitude: Double;
    Longitude: Double;
    Troco: Real;
  end;

function CreateReq: iRequisicao;
function RemoverNonoDigito(const Celular: string): string;
procedure getPedidos;
function UserID: Integer;
procedure getPedido(ID: String);
procedure ProcessaGravacaoPedido(Body: String);
function ExtrairCliente(JSON: TJSONObject): TCliente;
function ExtrairEndereco(JSON: TJSONObject; Cliente: TCliente; Pedido: TPedido)
  : TEndereco;
function ExtrairProdutos(JSON: TJSONObject): TArray<TProduto>;
function ExtrairPagamento(JSON: TJSONObject): TPagamento;
function ExtrairPedido(JSON: TJSONObject): TPedido;
function RemoverAcentos(const Texto: string): string;
function GeraCodigoPorDiaPedido: Integer;
function GetBaseURL: String;
function StatusPedidoNovo: Integer;
function GetCodigoProduto(CodigoSite: Integer): Integer;

function TipoPedido: Integer;
procedure ProcessarMesa(Cliente: TCliente; Produtos: TArray<TProduto>);
procedure ProcessarPedido(Pedido: TPedido; Cliente: TCliente;
  Endereco: TEndereco; Produtos: TArray<TProduto>; Pagamento: TPagamento);
function MontarDescricaoExtras(Extras: TArray<TExtra>): string;
procedure InserirProduto(Produtos: TArray<TProduto>; Mesa, Pedido: Integer;
  Conexao: TConexao; Usuario: Integer);
procedure ProcessamentoProduto(Pedido: TPedido; Produtos: TArray<TProduto>;
  Mesa: Integer; Conexao: TConexao; Usuario, StatusCode: Integer);
procedure ImprimirCozinha(Pedido: Integer);
function InsertTabelaPedidoBasica(Mesa: Integer): Integer;
procedure AtualizaStatusPedido(Pedido, Status: Integer);
function AtualizaSite(Pedido, CodigoDia, Codigo: Integer): Integer;

function UsuarioMesa: Integer;
function UsuarioSite: Integer;

implementation

uses
  FireDAC.Comp.Client;

function CreateReq: iRequisicao;
begin
  Result := iRequisicao.Create(nil);
  Result.BaseURL := GetBaseURL;
end;

function UsuarioMesa: Integer;
begin
  Result := -1;
end;

function UsuarioSite: Integer;
begin
  Result := -2;
end;

function UserID: Integer;
var
  iReq: iRequisicao;
  JSON: TJSONObject;
begin
  iReq := CreateReq;
  iReq.URL := 'v2/status';
  try
    iReq.Execute;

    JSON := TJSONObject.ParseJSONValue(iReq.Retorno) as TJSONObject;

    Result := JSON.GetValue<Integer>('modulos.usuario', 0);

  except
    Result := 0;
  end;
  iReq.Free;
end;

function AtualizaSite(Pedido, CodigoDia, Codigo: Integer): Integer;
var
  iReq: iRequisicao;
  JSON: TJSONObject;
  Retorno: String;
  Conexao: TConexao;
begin
  CodigoDia := GeraCodigoPorDiaPedido;
  Result := CodigoDia;
  if CodigoDia = 0 then
    exit;
  Conexao := TConexao.Create('AtualizaSite');
  Conexao.SQL.Add
    ('update pedido set codigo_pedido_dia = :dia where codigo = :codigo');
  Conexao.Parametros('codigo', Codigo);
  Conexao.Parametros('dia', CodigoDia);
  Conexao.ExecuteSQL;
  Conexao.Free;

  iReq := iRequisicao.Create(nil);
  iReq.BaseURL := 'https://ws.goopedir.com/v2/pedido.php';
  JSON := TJSONObject.Create;
  JSON.AddPair('CodigoPedido', Pedido);
  JSON.AddPair('CodigoDia', FormatFloat('000', CodigoDia));
  JSON.AddPair('CodigoSistema', Codigo);
  iReq.Body(JSON);
  iReq.Metodo := mPost;
  try
    iReq.Execute;
    Retorno := iReq.Retorno;
  except

  end;

  iReq.Free;

end;

procedure AtualizaStatusPedido(Pedido, Status: Integer);
var
  iReq: iRequisicao;
begin

  iReq := CreateReq;
  try
    iReq.URL := 'v1/pedido/status/' + Pedido.ToString + '/' +
      Status.ToString + '/';
    iReq.Metodo := mPut;
    iReq.Execute;
  except

  end;
  iReq.Free;
end;

function RemoverNonoDigito(const Celular: string): string;
begin
  Result := Celular;
  // Verifica se o n�mero tem 11 d�gitos e se o nono d�gito � '9'
  if (Length(Result) = 11) and (Result[3] = '9') then
    Result := Copy(Result, 1, 2) + Copy(Result, 4, 8); // Remove o nono d�gito
end;

function InsertTabelaPedidoBasica(Mesa: Integer): Integer;
var
  Req: iRequisicao;
  JsonOb: TJSONObject;
begin
  Req := CreateReq;
  Req.URL := 'v1/codigo/pedido/:mesa';
  Req.parametroUrli('mesa', Mesa);
  try
    Req.Execute;
    JsonOb := TJSONObject.ParseJSONValue(Req.Retorno) as TJSONObject;

    Result := JsonOb.GetValue('codigo').Value.ToInteger;
  except

  end;
  Req.Free;
end;

procedure ImprimirCozinha(Pedido: Integer);
var
  Req: iRequisicao;
begin
  Req := CreateReq;

  Req.URL := 'v1/produtos/pedido/2/' + Pedido.ToString;
  try
    Req.TempoExpiracao := 10 * 1000;
    Req.Execute;

    Req.URL := 'v1/imprimir';
    Req.Body(Req.Retorno);
    Req.Metodo := mPost;
    Req.Execute;

  except
    on E: Exception do
    begin

    end;

  end;

  Req.Free;
end;

function MontarDescricaoExtras(Extras: TArray<TExtra>): string;
var
  Categorias: TDictionary<string, TStringList>;
  Extra: TExtra;
  Categoria, DescricaoFormatada: string;
  I: Integer;
begin
  Categorias := TDictionary<string, TStringList>.Create;
  try
    // Agrupa os extras por categoria
    for Extra in Extras do
    begin
      // Formata a descri��o (primeira letra mai�scula)
      DescricaoFormatada := UpperCase(Copy(Extra.Descricao, 1, 1)) +
        LowerCase(Copy(Extra.Descricao, 2, Length(Extra.Descricao)));

      // Verifica se a categoria j� existe no dicion�rio
      if not Categorias.ContainsKey(Extra.Categoria) then
        Categorias.Add(Extra.Categoria, TStringList.Create);

      // Adiciona a descri��o repetidamente conforme a quantidade
      for I := 1 to Trunc(Extra.Quantidade) do
        Categorias[Extra.Categoria].Add(DescricaoFormatada);
    end;

    // Monta a string final
    Result := '';
    for Categoria in Categorias.Keys do
    begin
      Result := Result + '<p><b>' + UpperCase(Copy(Categoria, 1, 1)) +
        LowerCase(Copy(Categoria, 2, Length(Categoria))) + ':</b> <i>' +
        Categorias[Categoria].DelimitedText.Replace(' ', ', ') + '</i></p>';
    end;

    Result := Result;
  finally
    // Libera a mem�ria das listas de categorias
    for Categoria in Categorias.Keys do
      Categorias[Categoria].Free;
    Categorias.Free;
  end;
end;

function GetCodigoProduto(CodigoSite: Integer): Integer;
var
  Conexao: TConexao;
begin
  Conexao := TConexao.Create('GetCodigoProduto');
  Conexao.SQL.Add('select codigo, 0 as zero from produto where id_site = :id');
  Conexao.Parametros('id', CodigoSite);
  try
    Result := Conexao.FieldByName('codigo');
  except
    Result := 0;
  end;

  Conexao.Free;

end;

function TipoPedido: Integer;
var
  Conexao: TConexao;
begin
  Conexao := TConexao.Create('TipoPedido');
  Conexao.SQL.Add('select 0 as zero,aceitar_pedidos_site from dados_whatsapp');
  try
    Result := Conexao.FieldByName('aceitar_pedidos_site');
  except
    Result := 1;
  end;
  Conexao.Free;
end;

function StatusPedidoNovo: Integer;
var
  Conexao: TConexao;
begin
  Conexao := TConexao.Create('StatusPedidoNovo');
  Conexao.SQL.Add('select 0 as zero,status_pedidos_site from dados_whatsapp');
  try
    Result := Conexao.FieldByName('status_pedidos_site');
  except
    Result := 1;
  end;
  Conexao.Free;
end;

function GetBaseURL: String;
begin
  Result := 'http://localhost:2121/'
end;

function GeraCodigoPorDiaPedido: Integer;
var
  Req: iRequisicao;
begin

  Req := CreateReq;
  Req.URL := 'v1/codigo/pedido/dia';
  try
    Req.Execute;
    Result := Req.Retorno.ToInteger;
  except
    Result := 0;
  end;

  Req.Free;

end;

function RemoverAcentos(const Texto: string): string;
const
  ComAcentos = '����������������������������������������������%-';
  SemAcentos = 'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC  ';
var
  I: Integer;
begin
  Result := Texto;
  for I := 1 to Length(Result) do
  begin
    if Pos(Result[I], ComAcentos) > 0 then
      Result[I] := SemAcentos[Pos(Result[I], ComAcentos)];
  end;

  Result := UpperCase(Result);

end;

function ExtrairCliente(JSON: TJSONObject): TCliente;
var
  Conexao: TConexao;
  Dados: TFDmemTable;
begin
  Result.Nome := RemoverAcentos(JSON.GetValue<string>('cliente.nome', ''));
  Result.Celular := JSON.GetValue<string>('cliente.celular', '');
  Result.CPF := JSON.GetValue<string>('cliente.cpf', '');
  Result.Nascimento := JSON.GetValue<string>('cliente.nascimento', '');
  Conexao := TConexao.Create('ExtrairCliente');

  try

    if StrToInt(Result.Celular) < 999 then
    begin
      Conexao.SQL.Add
        ('SELECT m.id_mesa as id, selecionada, concat(mt.descricao," ", m.nr_mesa) as nome FROM mesa as m');
      Conexao.SQL.Add
        ('join mesa_tipo as mt on mt.id_mesa_tipo = m.fk_tipo_mesa');
      Conexao.SQL.Add
        ('where concat(upper(mt.descricao)," ", m.nr_mesa) = :nome');
      Dados := TFDmemTable.Create(nil);
      Conexao.Parametros('nome', UpperCase(Result.Nome));
      Dados.LoadFromJSON(Conexao.ConsultaSQL);
      Result.Mesa := Dados.FieldByName('id').AsInteger;
      Result.PedidoMesa := Dados.FieldByName('selecionada').AsInteger;
    end;
  except
    Result.Mesa := 0;
  end;

  Conexao.SQL.Add
    ('select codigo, 0 as zero from cliente where celular = :celular or celular_wpp = :celular');
  Conexao.Parametros('celular', (Result.Celular));
  try
    Result.Codigo := Conexao.FieldByName('codigo');
  except
    Result.Codigo := 0;
  end;

  if Result.Codigo = 0 then
  begin
    Result.Codigo := Conexao.GerarID('cliente', 'codigo');

    Conexao.SQL.Add
      ('insert into cliente (codigo,nome,celular,celular_wpp,ativo,origem,cpf,data_nascimento)');
    Conexao.SQL.Add
      ('values (:codigo,:nome,:celular,:celular,1,1,:cpf,:data_nascimento)');

  end
  else
  begin
    Conexao.SQL.Add
      ('update cliente set nome = :nome, celular = :celular, celular_wpp = :celular, cpf = :cpf, data_nascimento = :data_nascimento where codigo = :codigo');
  end;
  Conexao.Parametros('codigo', Result.Codigo);
  Conexao.Parametros('nome', RemoverAcentos(Result.Nome));
  Conexao.Parametros('celular', (Result.Celular));
  Conexao.Parametros('cpf', Result.CPF);
  Conexao.Parametros('data_nascimento', Result.Nascimento);

  Conexao.ExecuteSQL;
  Conexao.Free;
end;

function ExtrairEndereco(JSON: TJSONObject; Cliente: TCliente; Pedido: TPedido)
  : TEndereco;
var
  Conexao: TConexao;
begin
  Result.Rua := JSON.GetValue<string>('endereco.rua', '');
  Result.Numero := JSON.GetValue<string>('endereco.numero', '');
  Result.Bairro := JSON.GetValue<string>('endereco.bairro', '');
  Result.Cidade := JSON.GetValue<string>('endereco.cidade', '');
  Result.Estado := JSON.GetValue<string>('endereco.estado', '');
  Result.Complemento := JSON.GetValue<string>('endereco.complemento', '');
  if Result.Rua = '' then
  begin
    Result.Codigo := 0;
    exit;
  end;

  Conexao := TConexao.Create('ExtrairEndereco');
  Conexao.SQL.Add
    ('select * from cliente_endereco where codigo_cliente = :cliente and rua = :rua and bairro = :bairro and numero = :numero');
  Conexao.Parametros('cliente', Cliente.Codigo);
  Conexao.Parametros('rua', Result.Rua);
  Conexao.Parametros('bairro', Result.Bairro);
  Conexao.Parametros('numero', Result.Numero);

  try
    Result.Codigo := Conexao.FieldByName('codigo');
  except
    Result.Codigo := 0;
  end;

  if Result.Codigo = 0 then
  begin
    Result.Codigo := Conexao.GerarID('cliente_endereco', 'codigo');
    Conexao.SQL.Add
      ('insert into cliente_endereco (codigo,codigo_cliente,descricao,tipo,numero,rua,bairro,cidade,estado,complemento,ativo)');
    Conexao.SQL.Add
      ('values (:codigo,:cliente,"site",1,:numero,:rua,:bairro,:cidade,:estado,:complemento,1)')
  end
  else
  begin
    Conexao.SQL.Add
      ('update cliente_endereco set numero = :numero, rua = :rua, bairro = :bairro, cidade = :cidade, estado = :estado, complemento = :complemento');
    Conexao.SQL.Add('where codigo = :codigo and codigo_cliente = :cliente');
  end;
  Conexao.Parametros('codigo', Result.Codigo);
  Conexao.Parametros('cliente', Cliente.Codigo);
  Conexao.Parametros('numero', RemoverAcentos(Result.Numero));
  Conexao.Parametros('rua', RemoverAcentos(Result.Rua));
  Conexao.Parametros('bairro', RemoverAcentos(Result.Bairro));
  Conexao.Parametros('cidade', RemoverAcentos(Result.Cidade));
  Conexao.Parametros('estado', RemoverAcentos(Result.Estado));
  Conexao.Parametros('complemento', RemoverAcentos(Result.Complemento));

  Conexao.ExecuteSQL;

  Conexao.Free;
end;

function ExtrairProdutos(JSON: TJSONObject): TArray<TProduto>;
var
  ProdutosArray: TJSONArray;
  ProdutoJSON: TJSONObject;
  ExtrasArray: TJSONArray;
  ExtraJSON: TJSONObject;
  I, J: Integer;
  Conexao: TConexao;
begin
  Conexao := TConexao.Create('ExtrairProdutos');
  ProdutosArray := JSON.GetValue<TJSONArray>('produtos');
  SetLength(Result, ProdutosArray.Count);

  for I := 0 to ProdutosArray.Count - 1 do
  begin
    ProdutoJSON := ProdutosArray[I] as TJSONObject;

    // Extrai os dados b�sicos do produto
    Result[I].ID := ProdutoJSON.GetValue<string>('tabela', '');
    Result[I].CodigoProduto := ProdutoJSON.GetValue<Integer>('id', 0);
    Result[I].Nome := ProdutoJSON.GetValue<string>('nome', '');
    Result[I].Preco := ProdutoJSON.GetValue<Double>('preco');
    Result[I].Unitario := ProdutoJSON.GetValue<Double>('unitario');
    Result[I].Quantidade := ProdutoJSON.GetValue<Integer>('quantidade');
    Result[I].CodigoProduto := GetCodigoProduto(Result[I].CodigoProduto);
    Result[I].Codigo := Conexao.GerarID('pedido_produtos', 'codigo');
    Result[I].ValorExtra := 0;

    if Result[I].Preco = 0 then
    begin
      SetLength(Result, 0);
      exit;
    end;

    // Extrai os extras, se existirem
    if ProdutoJSON.TryGetValue<TJSONArray>('extra', ExtrasArray) then
    begin
      SetLength(Result[I].Extra, ExtrasArray.Count);
      for J := 0 to ExtrasArray.Count - 1 do
      begin
        ExtraJSON := ExtrasArray[J] as TJSONObject;
        Result[I].Extra[J].Categoria := ExtraJSON.GetValue<string>
          ('categoria', '');
        Result[I].Extra[J].Descricao := ExtraJSON.GetValue<string>
          ('descricao', '');
        Result[I].Extra[J].Valor := ExtraJSON.GetValue<Real>('valor', 0);
        Result[I].Extra[J].Quantidade := ExtraJSON.GetValue<Real>
          ('quantidade', 0);
        Result[I].Extra[J].Codigo :=
          Conexao.GerarID('pedido_produto_sap', 'id');
        Result[I].ValorExtra := (Result[I].ValorExtra * Result[I].Quantidade) +
          Result[I].Extra[J].Valor;
      end;
    end
    else
    begin
      SetLength(Result[I].Extra, 0);
      // Se n�o houver extras, define como array vazio
    end;
    if Result[I].ValorExtra > Result[I].Preco then
      Result[I].ValorExtra := Result[I].Preco;

    if Result[I].ValorExtra > 0 then
    begin
      Result[I].ValorExtra := Result[I].ValorExtra - Result[I].Unitario;
    end;
  end;

end;

function ExtrairPagamento(JSON: TJSONObject): TPagamento;
var
  Conexao: TConexao;
begin
  Result.Descricao := JSON.GetValue<string>('pagamento.descricao', '');
  Result.MP := JSON.GetValue<string>('pagamento.mp', '');
  Result.Transacao := JSON.GetValue<string>('pagamento.transacao', '');

  Conexao := TConexao.Create('ExtrairPagamento');
  Conexao.SQL.Add('select * from tipo_pagamento where descricao = :descricao');
  Conexao.Parametros('descricao', Result.Descricao);
  try
    Result.Codigo := Conexao.FieldByName('codigo');
  except
    Result.Codigo := 0;
  end;

  if Result.Codigo = 0 then
  begin
    Conexao.SQL.Add('insert into tipo_pagamento (codigo,descricao)');
    Conexao.SQL.Add('values (:codigo,:descricao)');
    Conexao.Parametros('codigo', Result.Codigo);
    Conexao.Parametros('descricao', Result.Descricao);
    Conexao.ExecuteSQL;
  end;
  Conexao.Free;

end;

function ExtrairPedido(JSON: TJSONObject): TPedido;
begin
  Result.ID := JSON.GetValue<string>('id', '');
  Result.Data := StrToDateTimeDef(JSON.GetValue<string>('data', ''), Now);
  Result.SubTotal := JSON.GetValue<Double>('sub', 0);
  Result.Desconto := JSON.GetValue<Double>('desconto', 0);
  Result.Taxa := JSON.GetValue<Double>('taxa', 0);
  Result.Total := JSON.GetValue<Double>('total', 0);
  Result.URL := JSON.GetValue<string>('url', '');
  Result.Partner := JSON.GetValue<string>('partner', '');
  Result.Cupom := JSON.GetValue<string>('cupom', '');
  Result.Latitude := JSON.GetValue<Double>('latitude', 0);
  Result.Longitude := JSON.GetValue<Double>('longitude', 0);
  Result.Troco := JSON.GetValue<Double>('troco', 0);
  Result.Troco := Result.Troco - Result.Total;
  if Result.Troco = Result.Total then
    Result.Troco := 0;

  if Result.Troco < 0 then
    Result.Troco := 0;

end;

procedure getPedidos;
var

  // JSONArray: TJSONArray;
  // JSONValue: TJSONValue;
  // JSONObject: TJSONObject;
  // I: Integer;
  // Req: iRequisicao;
  // User: Integer;
  Req: iRequisicao;
  User: Integer;

  LRootVal: TJSONValue;
  LRootObj: TJSONObject;

  ArrPedidos: TJSONArray;
  ArrMotoboy: TJSONArray;
  ArrProduto: TJSONArray;

  I: Integer;
  ItemVal: TJSONValue;
  ItemObj: TJSONObject;
  IdPedido: Integer;
  Conexao: TConexao;
  CodigoMotoboy: Integer;
  CodigoPedido: Integer;
  CodigoPedidoiFood: String;
  CodigoPedidoMotoboy: Integer;
  FRequestStatus: iRequisicao;
begin

  User := UserID;

  Req := iRequisicao.Create(nil);
  try
    Req.BaseURL := API_BASE_URL;
    Req.URL := 'api/goopedir/pedidos/motoboy?codigo=' + User.ToString;
    Req.Token(GetToken);

    Req.Execute;

    // Parse do JSON retornado (agora � OBJETO na raiz)
    LRootVal := TJSONObject.ParseJSONValue(Req.Retorno);
    try
      if not Assigned(LRootVal) then
        exit;

      if not(LRootVal is TJSONObject) then
        exit;

      LRootObj := LRootVal as TJSONObject;

      // Pega os arrays "pedidos" e "motoboy"
      ArrPedidos := LRootObj.Values['pedidos'] as TJSONArray;
      ArrMotoboy := LRootObj.Values['motoboy'] as TJSONArray;
      ArrProduto := LRootObj.Values['categorias'] as TJSONArray;

      // ======== Processar PRODUTOS =========
      if Assigned(ArrProduto) then
      begin
        for I := 0 to ArrProduto.Count - 1 do
          begin
            ItemVal := ArrProduto.Items[I];
            if ItemVal is TJSONObject then
            begin
               ItemObj := ItemVal as TJSONObject;
               try
               ImportaProduto(ItemObj);
               except

               end;

            end;

          end;
      end;

      // ======== Processar PEDIDOS (se quiser) ========
      if Assigned(ArrPedidos) then
      begin
        for I := 0 to ArrPedidos.Count - 1 do
        begin
          ItemVal := ArrPedidos.Items[I];
          if ItemVal is TJSONObject then
          begin
            ItemObj := ItemVal as TJSONObject;
            getPedido(ItemObj.GetValue<String>('id'));
            // Ex.: ler campos do pedido, se houver
            // var pedidoId := ItemObj.GetValue<Integer>('id');
            // ... sua l�gica aqui ...
          end;
        end;
      end;
      FRequestStatus := iRequisicao.Create(nil);
      FRequestStatus.BaseURL := BaseUrlLocal;

      // ======== Processar MOTOBOY ========
      if Assigned(ArrMotoboy) then
      begin
        Conexao := TConexao.Create('ArrMotoboy');
        for I := 0 to ArrMotoboy.Count - 1 do
        begin
          ItemVal := ArrMotoboy.Items[I];
          if ItemVal is TJSONObject then
          begin
            ItemObj := ItemVal as TJSONObject;
            Conexao.SQL.Add('SELECT * FROM motoboy where upper(nome) like "%' +
              ItemObj.GetValue<string>('nome') + '%" or id_site = :id');
            Conexao.Parametros('id', ItemObj.GetValue<Integer>('motoboy'));
            try
              CodigoMotoboy := Conexao.FieldByName('codigo');
            except
              on E: Exception do
              begin

                CodigoMotoboy := 0;

                CodigoMotoboy := Conexao.GerarID('motoboy', 'codigo');
                Conexao.SQL.Add
                  ('insert into motoboy (codigo,nome,celular,celular_wpp,ativo,id_site)');
                Conexao.SQL.Add
                  ('values (:codigo,:nome,:celular,:celular_wpp,1,:id_site)');
                Conexao.Parametros('codigo', CodigoMotoboy);
                Conexao.Parametros('nome', ItemObj.GetValue<string>('nome'));
                Conexao.Parametros('celular_wpp',
                  ItemObj.GetValue<string>('celular'));
                Conexao.Parametros('celular',
                  ItemObj.GetValue<string>('celular'));
                Conexao.Parametros('id_site',
                  ItemObj.GetValue<string>('motoboy'));
                Conexao.ExecuteSQL;
              end;
            end;

            Conexao.SQL.Add
              ('select 0 as zero, codigo from pedido where pedido_site = :pedido');
            Conexao.Parametros('pedido', ItemObj.GetValue<string>('id_pedido'));
            try
              CodigoPedido := Conexao.FieldByName('codigo');
            except
              CodigoPedido := 0;
            end;

            if ItemObj.GetValue<Integer>('id_pedido') = 1 then
            begin
              FRequestStatus.URL := 'v1/pedido/status/' +
                CodigoPedido.ToString + '/3/';
            end
            else
            begin
              FRequestStatus.URL := 'v1/pedido/status/' +
                CodigoPedido.ToString + '/5/';
            end;
            try
              FRequestStatus.Metodo := mPut;
              FRequestStatus.TempoExpiracao := 3000;
              FRequestStatus.Execute;
            except

            end;

            Conexao.SQL.Add
              ('select 0 as zero, id_ifood from pedido where codigo = :codigo');
            Conexao.Parametros('codigo', CodigoPedido);

            try
              CodigoPedidoiFood := Conexao.FieldByName('id_ifood');
            except
              CodigoPedidoiFood := '';
            end;

            if CodigoPedidoiFood <> '' then
            begin
              try
                FRequestStatus.URL := 'v1/util/ifood/despachar/' +
                  CodigoPedidoiFood;
                FRequestStatus.Metodo := mPost;
                FRequestStatus.TempoExpiracao := 3000;
                FRequestStatus.Execute;
              except

              end;
            end;

            CodigoPedidoMotoboy := Conexao.GerarID('pedido_motoboy', 'codigo');
            Conexao.SQL.Add
              ('insert into pedido_motoboy (codigo,codigo_motoboy,codigo_pedido,hora_pego_motoboy,status)');
            Conexao.SQL.Add
              ('values (:codigo,:codigo_motoboy,:codigo_pedido,:hora_pego_motoboy,0)');
            Conexao.Parametros('codigo', CodigoPedidoMotoboy);
            Conexao.Parametros('codigo_motoboy', CodigoMotoboy);
            Conexao.Parametros('codigo_pedido', CodigoPedido);
            Conexao.Parametros('hora_pego_motoboy',
              ItemObj.GetValue<string>('hora'));
            Conexao.ExecuteSQL;

            try
              Req.URL := 'api/goopedir/motoboy/status?codigo=' +
                ItemObj.GetValue<string>('id_pedido');
              Req.Metodo := mPost;
              Req.Token(GetToken);
              Req.Execute;
            except

            end;






            // Ex.: pegar id_pedido e chamar sua rotina
            // IdPedido := ItemObj.GetValue<Integer>('id_pedido');
            // getPedido(IdPedido.ToString);

            // Se precisar de outros campos:
            // var codigo := ItemObj.GetValue<Integer>('codigo');
            // var status := ItemObj.GetValue<Integer>('status');
            // var dataISO := ItemObj.GetValue<string>('data'); // "2025-08-29T03:00:00.000Z"
            // var hora    := ItemObj.GetValue<string>('hora'); // "22:32:18"
            // ... sua l�gica aqui ...
          end;
        end;
        Conexao.Free;
      end;

    finally
      // Importante: liberar apenas o n� raiz; os filhos s�o owned por ele
      LRootVal.Free;
    end;

  finally
    Req.Free;
  end;

end;

procedure getPedido(ID: String);
var
  Req: iRequisicao;
begin
  Req := iRequisicao.Create(nil);
  Req.BaseURL := 'https://ws.goopedir.com/v2/pedido.php?codigo=' + ID;
  try
    Req.Execute;
    ProcessaGravacaoPedido(Req.Retorno);
  except
  end;
  Req.Free;

end;

procedure ProcessamentoProduto(Pedido: TPedido; Produtos: TArray<TProduto>;
  Mesa: Integer; Conexao: TConexao; Usuario, StatusCode: Integer);
var
  ValidaPedido: Boolean;
  Notificar: Boolean;
  Impressao: Integer;
begin
  // Inserir os produtos
  case TipoPedido of
    0:
      begin
        Notificar := False;

      end
  else
    begin
      Notificar := True;
    end;
  end;

  InserirProduto(Produtos, 0, Pedido.Codigo, Conexao, UsuarioSite);

  Conexao.SQL.Add
    ('select count(*) as tot, 0 as zero from pedido_produtos where codigo_pedido = :codigo');
  Conexao.Parametros('codigo', Pedido.Codigo);

  try
    ValidaPedido := Conexao.FieldByName('tot') = Length(Produtos);
  except
    ValidaPedido := False;
  end;

  if not ValidaPedido then
    Notificar := ValidaPedido;

  // Libera produtos para serem impressos na cozinha

  if ValidaPedido then
  begin
    Impressao := Conexao.GerarID('impressao_pedido', 'id');
    Conexao.SQL.Add('delete from impressao_pedido where id_pedido = :pedido');
    Conexao.Parametros('pedido', Pedido.Codigo);
    Conexao.ExecuteSQL;

    Conexao.SQL.Add
      ('insert into impressao_pedido (id,data_solicitacao, hora_solicitacao,id_pedido,status)');
    Conexao.SQL.Add('values  (:id,current_date, current_time,:pedido,:status)');
    Conexao.Parametros('id', Impressao);
    Conexao.Parametros('pedido', Pedido.Codigo);
    if Notificar then
      Conexao.Parametros('status', 0)
    else
      Conexao.Parametros('status', 1);
    Conexao.ExecuteSQL;

    Pedido.CodigoDia := AtualizaSite(Pedido.ID.ToInteger, Pedido.CodigoDia,
      Pedido.Codigo);

    if ((Notificar) and (Pedido.CodigoDia > 0)) then
    begin
      ImprimirCozinha(Pedido.Codigo);
      AtualizaStatusPedido(Pedido.Codigo, StatusCode);
    end;
  end
  else
  begin
    Conexao.SQL.Add('delete from pedido where codigo = :codigo');
    Conexao.Parametros('codigo', Pedido.Codigo);
    Conexao.ExecuteSQL;

  end;
end;

procedure InserirProduto(Produtos: TArray<TProduto>; Mesa, Pedido: Integer;
  Conexao: TConexao; Usuario: Integer);
var
  Produto: TProduto;
  Extra: TExtra;
  Req: iRequisicao;
  I: Integer;
begin
  Req := iRequisicao.Create(nil);
  Req.BaseURL := GetBaseURL;

  for Produto in Produtos do
  begin
    Conexao.SQL.Add('delete from pedido_produtos where id_site = :site');
    Conexao.Parametros('site', Produto.ID);
    Conexao.ExecuteSQL;

    Conexao.SQL.Add
      ('insert into pedido_produtos (codigo,codigo_pedido,codigo_produto,valor_unitario,quantidade,valor_total,valor_adicional,impressao,html,usuario,id_site)');
    Conexao.SQL.Add
      ('values (:codigo,:codigo_pedido,:codigo_produto,:valor_unitario,:quantidade,:valor_total,:valor_adicional,0,:html,:usuario, :site)');
    Conexao.Parametros('codigo', Produto.Codigo);
    Conexao.Parametros('codigo_pedido', Pedido);
    Conexao.Parametros('codigo_produto', Produto.CodigoProduto);
    Conexao.Parametros('valor_unitario', Produto.Unitario);
    Conexao.Parametros('quantidade', Produto.Quantidade);
    Conexao.Parametros('valor_total', Produto.Preco);
    Conexao.Parametros('valor_adicional', Produto.ValorExtra);
    Conexao.Parametros('site', Produto.ID);
    Conexao.Parametros('usuario', Usuario);
    Conexao.Parametros('html', MontarDescricaoExtras(Produto.Extra));
    Conexao.ExecuteSQL;

    for Extra in Produto.Extra do
    begin

      for I := 1 to Trunc(Extra.Quantidade) do
      begin

        Conexao.SQL.Add
          ('insert into pedido_produto_sap (codigo_pedido_produto,tipo, nomeclatura,descricao,valor)');
        Conexao.SQL.Add('values (:codigo,0, :nomeclatura,:descricao,:valor)');
        Conexao.Parametros('codigo', Produto.Codigo);
        Conexao.Parametros('nomeclatura', Extra.Categoria);
        Conexao.Parametros('descricao', Extra.Descricao);
        Conexao.Parametros('valor', Extra.Valor);
        Conexao.ExecuteSQL;
      end;

    end;

    if Mesa > 0 then
    begin
      Conexao.SQL.Add
        ('update mesa set tot_mesa = tot_mesa + :total  where id_mesa = :id');
      Conexao.Parametros('id', Mesa);
      Conexao.Parametros('total', Produto.Preco);
      Conexao.ExecuteSQL;
    end;

    Conexao.SQL.Add
      ('insert into impressao_pedido_produto (id_pedido,status,data_solicitacao,hora_solicitacao,usuario) values (:codigo,1,curdate(),curtime(),-2)');
    Conexao.Parametros('codigo', Produto.Codigo);
    Conexao.ExecuteSQL;

    Req.URL := 'v1/baixa/estoque/produto/' + Produto.CodigoProduto.ToString +
      '/' + Produto.Quantidade.ToString;
    Req.Metodo := mPost;
    try
      Req.Execute;
    except

    end;

    Req.URL := 'v1/baixa/estoque/insulmo/' + Produto.Codigo.ToString;
    Req.Metodo := mPost;
    try
      Req.Execute;
    except

    end;

  end;
  Req.Free;
end;

procedure ProcessarPedido(Pedido: TPedido; Cliente: TCliente;
  Endereco: TEndereco; Produtos: TArray<TProduto>; Pagamento: TPagamento);
var
  Conexao: TConexao;
  Impressao: Integer;
  StatusCode: Integer;
  Notificar: Boolean;
  Dados: TFDmemTable;
  ValidaPedido: Boolean;
begin
  StatusCode := StatusPedidoNovo;

  case TipoPedido of
    0:
      begin
        Notificar := False;
        StatusCode := 9;
      end
  else
    begin
      Notificar := True;
    end;
  end;

  Conexao := TConexao.Create('ProcessarPedido');
  Conexao.SQL.Add
    ('select codigo, codigo_pedido_dia as dia from pedido where id_pedido_site = :id');
  Conexao.Parametros('id', Pedido.ID);
  Dados := TFDmemTable.Create(nil);
  Dados.LoadFromJSON(Conexao.ConsultaSQL);
  if Dados.RecordCount > 0 then
  begin

    try
      Pedido.Codigo := Dados.FieldByName('codigo').AsInteger;
      Pedido.CodigoDia := Dados.FieldByName('dia').AsInteger;
    except
      Pedido.Codigo := 0;
    end;
    ProcessamentoProduto(Pedido, Produtos, 0, Conexao, -2, StatusCode);
    if Pedido.Codigo > 0 then
    begin
      AtualizaSite(Pedido.ID.ToInteger, Pedido.CodigoDia, Pedido.Codigo);
      Conexao.Free;
      exit;
    end;

  end;

  Pedido.Codigo := InsertTabelaPedidoBasica(0);
  Conexao.SQL.Add
    ('update pedido set codigo_pedido_dia = :dia, codigo_cliente = :cliente, codigo_cliente_endereco = :endereco, status = :status, desc_desconto_ifood = :cupom,');
  Conexao.SQL.Add
    ('valor_pedido = :pedido, valor_desconto = :desconto, valor_taxa_entrega = :entrega, valor_total_pedido = :total, troco = :troco, pedido_site = :site, id_pedido_site = :site,');
  Conexao.SQL.Add
    ('tipo_pagamento = :pagamento, origem = 2, url = :url, partner = :partner, cpf = :cpf, nome = :nome, latitude = :latitude, longitude = :logitude, mp = :mp');
  Conexao.SQL.Add('where codigo = :codigo');
  Conexao.Parametros('site', Pedido.ID);
  Conexao.Parametros('codigo', Pedido.Codigo);
  Pedido.CodigoDia := 0;
  // Pedido.CodigoDia := GeraCodigoPorDiaPedido;
  Conexao.Parametros('dia', Pedido.CodigoDia);
  Conexao.Parametros('cupom', Pedido.Cupom);

  Conexao.Parametros('cliente', Cliente.Codigo);
  Conexao.Parametros('endereco', Endereco.Codigo);
  Conexao.Parametros('status', StatusCode);
  Conexao.Parametros('pedido', Pedido.SubTotal);
  Conexao.Parametros('desconto', Pedido.Desconto);
  Conexao.Parametros('entrega', Pedido.Taxa);
  Conexao.Parametros('total', Pedido.Total);
  Conexao.Parametros('troco', Pedido.Troco);
  Conexao.Parametros('pagamento', Pagamento.Codigo);
  Conexao.Parametros('mp', Pagamento.Transacao);
  Conexao.Parametros('url', Pedido.URL);
  Conexao.Parametros('partner', Pedido.Partner);
  Conexao.Parametros('cpf', Cliente.CPF);
  Conexao.Parametros('nome', RemoverAcentos(Cliente.Nome));
  Conexao.Parametros('latitude', Pedido.Latitude);
  Conexao.Parametros('logitude', Pedido.Longitude);
  Conexao.ExecuteSQL;

  ProcessamentoProduto(Pedido, Produtos, 0, Conexao, -2, StatusCode);

  Conexao.Free;
end;

procedure ProcessarMesa(Cliente: TCliente; Produtos: TArray<TProduto>);
var
  Conexao: TConexao;

begin

  Conexao := TConexao.Create('ProcessarMesa');

  if Cliente.PedidoMesa = 0 then
  begin
    // Faz insert basico da tabela de Pedido
    Cliente.PedidoMesa := InsertTabelaPedidoBasica(Cliente.Mesa);
  end
  else
  begin
    Conexao.SQL.Add
      ('update pedido set codigo_cliente = :cliente where codigo = :codigo');
    Conexao.Parametros('cliente', Cliente.Codigo);
    Conexao.Parametros('codigo', Cliente.PedidoMesa);
    Conexao.ExecuteSQL;
  end;

  // Inserir os produtos
  InserirProduto(Produtos, Cliente.Mesa, Cliente.PedidoMesa, Conexao,
    UsuarioMesa);

  // Libera produtos para serem impressos na cozinha
  ImprimirCozinha(Cliente.PedidoMesa);

  Conexao.Free;

end;

procedure ProcessaGravacaoPedido(Body: String);
var
  JSON: TJSONObject;
  Cliente: TCliente;
  Endereco: TEndereco;
  Produtos: TArray<TProduto>;
  Pagamento: TPagamento;
  Pedido: TPedido;
  Conexao: TConexao;

begin

  JSON := TJSONObject.ParseJSONValue(Body) as TJSONObject; // Insira o JSON aqui
  try
    Pagamento := ExtrairPagamento(JSON);
    Cliente := ExtrairCliente(JSON);
    Pedido := ExtrairPedido(JSON);
    Endereco := ExtrairEndereco(JSON, Cliente, Pedido);
    Produtos := ExtrairProdutos(JSON);

    if Assigned(Produtos) then
    begin

      if Cliente.Mesa > 0 then
      begin
        // Adicionar Itens Na Mesa
        ProcessarMesa(Cliente, Produtos);
        AtualizaSite(Pedido.ID.ToInteger, Cliente.Mesa, Cliente.PedidoMesa);
      end
      else
      begin
        // Adicionar Novos Pedidos
        ProcessarPedido(Pedido, Cliente, Endereco, Produtos, Pagamento);
      end;
    end;

    // Agora voc� pode usar as vari�veis Cliente, Endereco, Produtos, Pagamento e Pedido
  finally
    JSON.Free;
  end;

end;

{ TGetPedidoThread }

constructor TGetPedidoThread.Create(const AID: string);
begin
  inherited Create(True); // Cria a thread em estado suspenso
  FID := AID; // Armazena o ID do pedido
  FreeOnTerminate := True; // Libera a thread automaticamente ap�s a execu��o
end;

procedure TGetPedidoThread.Execute;
begin
  inherited;
  try
    // Executa a fun��o getPedido em segundo plano
    getPedido(FID);
  except
    on E: Exception do
    begin
      // Trata exce��es, se necess�rio
      // Exemplo: Log de erro
    end;
  end;

end;

end.
