unit uPedidoSite;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, uRequisicao, Vcl.ExtCtrls, System.JSON,
  Vcl.StdCtrls, uImportacaoPedio, uExportacaoPedido;

type
  TfrmPedidoSite = class(TForm)
    ReqPedidos: iRequisicao;
    Timer1: TTimer;
    Button1: TButton;
    tMinimiza: TTimer;
    TrayIcon1: TTrayIcon;
    procedure Button1Click(Sender: TObject);
    procedure MedirTempoExecucao;
    procedure tMinimizaTimer(Sender: TObject);
  private
    { Private declarations }

  public
    { Public declarations }
  end;

var
  frmPedidoSite: TfrmPedidoSite;

implementation

{$R *.dfm}
{ TfrmPedidoSite }

procedure TfrmPedidoSite.Button1Click(Sender: TObject);
begin
  MedirTempoExecucao;
end;

procedure TfrmPedidoSite.MedirTempoExecucao;
var
  TempoInicial, TempoFinal: DWORD;
  TempoDecorrido: Integer;
begin
  TempoInicial := GetTickCount; // Marca o tempo inicial

  getPedidos; // Executa a fun��o que voc� quer medir

  TempoFinal := GetTickCount; // Marca o tempo final

  // Calcula o tempo decorrido em milissegundos
  TempoDecorrido := TempoFinal - TempoInicial;

  // Exibe o tempo decorrido em uma mensagem
  // showmessage
  (Format('A fun��o getPedidos demorou %d milissegundos para executar.',
    [TempoDecorrido]));
end;

procedure TfrmPedidoSite.tMinimizaTimer(Sender: TObject);

begin

  tMinimiza.Enabled := false;
  self.Hide();
  self.WindowState := wsMinimized;
  getPedidos;
  EnviarPedidos;
  Application.Terminate;
end;

end.
