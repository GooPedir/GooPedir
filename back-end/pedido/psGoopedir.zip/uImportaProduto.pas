﻿unit uImportaProduto;

interface

uses
  uRequisicao, System.JSON, System.SysUtils, Conexao, DataSet.Serialize,
  System.Generics.Collections, System.StrUtils, System.Classes,
  Vcl.Dialogs, uGlobais;

procedure ImportaProduto(Item: TJSONObject);
procedure Produto(Produto: TJSONObject; Conexao: TConexao);
procedure AtualizaStatusImportacao(Tabela,Codigo : String);

implementation

procedure AtualizaStatusImportacao(Tabela,Codigo : String);
var
requisicao : iRequisicao;
objeto : TJSONObject;
begin
objeto := TJSONObject.Create;
objeto.AddPair('tabela',Tabela);
objeto.AddPair('id',codigo);
requisicao := iRequisicao.Create(nil);
requisicao.BaseURL := API_BASE_URL;
requisicao.Token(GetToken);


requisicao.Metodo := mPost;
requisicao.URL := 'api/goopedir/produto/alterado';
requisicao.BODY(objeto.ToString);
try
   requisicao.Execute;
except

end;

requisicao.Free;
end;

function GetStr(o: TJSONObject; const Key: string;
  const Def: string = ''): string;
var
  V: TJSONValue;
begin
  V := o.Values[Key];
  if (V = nil) or V.Null then
    Exit(Def);
  Result := V.Value;
end;

function GetInt(o: TJSONObject; const Key: string;
  const Def: Integer = 0): Integer;
var
  V: TJSONValue;
begin
  V := o.Values[Key];
  if (V = nil) or V.Null then
    Exit(Def);
  Result := StrToIntDef(V.Value, Def);
end;

function GetBool(o: TJSONObject; const Key: string;
  const Def: Boolean = False): Boolean;
var
  V: TJSONValue;
begin
  V := o.Values[Key];
  if (V = nil) or V.Null then
    Exit(Def);
  Result := SameText(V.Value, 'true') or (V.Value = '1');
end;

function GetCurr(o: TJSONObject; const Key: string; const Def: Currency = 0)
  : Currency;
var
  V: TJSONValue;
  S: string;
begin
  V := o.Values[Key];
  if (V = nil) or V.Null then
    Exit(Def);
  S := StringReplace(V.Value, ',', '.', [rfReplaceAll]); // por via das dúvidas
  Result := StrToCurrDef(S, Def);
end;

procedure ImportaProduto(Item: TJSONObject);
var
  Conexao: TConexao;
  CodigoCategoria: Integer;
  ArrProduto: TJSONArray;
  I: Integer;
  ItemProduto: TJSONValue;
  ItemProdutoObj: TJSONObject;
begin
  Conexao := TConexao.Create('ImportaProduto');
  try
    // UP-SERT de CATEGORIA (tipo_produto) — igual você já vinha fazendo
    Conexao.SQL.Add
      ('SELECT * FROM tipo_produto WHERE id_site = :id OR upper(descricao) like "%'
      + UpperCase(Item.GetValue<String>('nome_cat')) + '%"');
    Conexao.Parametros('id', Item.GetValue<String>('id'));

    try
      CodigoCategoria := Conexao.FieldByName('codigo');

      // UPDATE
      Conexao.SQL.Add('update tipo_produto set ');
      Conexao.SQL.Add
        ('codigo = :codigo, descricao = :descricao, id_site = :id_site, ordem = :ordem, modificado_site = :modificado_site,');
      Conexao.SQL.Add
        ('local = :local, borda_topo_direito = :borda_topo_direito, borda_topo_esquerdo = :borda_topo_esquerdo,');
      Conexao.SQL.Add
        ('borda_inferior_esquerdo = :borda_inferior_esquerdo, borda_inferior_direito = :borda_inferior_direito, espacamento = :espacamento, fonte_nome = :fonte_nome,');
      Conexao.SQL.Add
        ('fonte_descricao = :fonte_descricao, cor_fundo = :cor_fundo, cor_nome = :cor_nome, url = :url,');
      Conexao.SQL.Add
        ('cor_descricao = :cor_descricao, opacidade = :opacidade, descricao_cat = :descricao_cat ');
      Conexao.SQL.Add('where codigo = :codigo');
    except
      // se não encontrou, faz INSERT
    end;

    if CodigoCategoria = 0 then
    begin
      Conexao.SQL.Clear;
      CodigoCategoria := Conexao.GerarID('tipo_produto', 'codigo');
      Conexao.SQL.Add
        ('insert into tipo_produto (codigo, descricao, id_site, ordem, modificado_site, local, borda_topo_direito, borda_topo_esquerdo, borda_inferior_direito,');
      Conexao.SQL.Add
        ('borda_inferior_esquerdo, espacamento, fonte_nome, fonte_descricao, cor_fundo, cor_nome, cor_descricao, opacidade, url, descricao_cat)');
      Conexao.SQL.Add
        ('values (:codigo, :descricao, :id_site, :ordem, :modificado_site, :local, :borda_topo_direito, :borda_topo_esquerdo, :borda_inferior_direito,');
      Conexao.SQL.Add
        (':borda_inferior_esquerdo, :espacamento, :fonte_nome, :fonte_descricao, :cor_fundo, :cor_nome, :cor_descricao, :opacidade, :url, :descricao_cat)');
    end;

    Conexao.Parametros('codigo', CodigoCategoria);
    Conexao.Parametros('descricao', Item.GetValue<String>('nome_cat'));
    Conexao.Parametros('descricao_cat', Item.GetValue<String>('descricao'));
    Conexao.Parametros('id_site', Item.GetValue<String>('id'));
    Conexao.Parametros('ordem', Item.GetValue<String>('ordem'));
    Conexao.Parametros('modificado_site', 1);
    Conexao.Parametros('local', Item.GetValue<String>('local'));
    Conexao.Parametros('borda_topo_direito',
      Item.GetValue<String>('borda_topo_direito'));
    Conexao.Parametros('borda_topo_esquerdo',
      Item.GetValue<String>('borda_topo_esquerdo'));
    Conexao.Parametros('borda_inferior_direito',
      Item.GetValue<String>('borda_inferior_direito'));
    Conexao.Parametros('borda_inferior_esquerdo',
      Item.GetValue<String>('borda_inferior_esquerdo'));
    Conexao.Parametros('espacamento', Item.GetValue<String>('altura'));
    Conexao.Parametros('fonte_nome', Item.GetValue<String>('fonte_nome'));
    Conexao.Parametros('fonte_descricao',
      Item.GetValue<String>('fonte_descricao'));
    Conexao.Parametros('cor_fundo', Item.GetValue<String>('cor_fundo'));
    Conexao.Parametros('cor_nome', Item.GetValue<String>('cor_nome'));
    Conexao.Parametros('cor_descricao', Item.GetValue<String>('cor_descricao'));
    Conexao.Parametros('opacidade', Item.GetValue<String>('opacidade'));
    Conexao.Parametros('url', Item.GetValue<String>('icon_cat'));
    Conexao.ExecuteSQL;

    AtualizaStatusImportacao('ws_cat',Item.GetValue<String>('id'));

    // Agora percorre produtos
    ArrProduto := Item.Values['produtos'] as TJSONArray;
    if Assigned(ArrProduto) then
    begin
      for I := 0 to ArrProduto.Count - 1 do
      begin
        ItemProduto := ArrProduto.Items[I];
        if ItemProduto is TJSONObject then
        begin
          ItemProdutoObj := ItemProduto as TJSONObject;

          // injeta o código da categoria no próprio JSON pra facilitar
          ItemProdutoObj.AddPair('__codigo_categoria',
            TJSONNumber.Create(CodigoCategoria));

          Produto(ItemProdutoObj, Conexao);
        end;
      end;
    end;

  finally
    Conexao.Free;
  end;
end;

procedure Produto(Produto: TJSONObject; Conexao: TConexao);
var
  CodigoProduto, CodigoCategoria: Integer;
  Nome, Desc, url: string;
  Valor, PromoValor, FidelidadeValor: Currency;
  Ativo, Novidade, VemBuscar, Delivery: Boolean;
  Ordem: Integer;
  IdSite, Tipos: string;

  procedure UpsertExtras(const ACodProd: Integer; Arr: TJSONArray);
  var
    I, j: Integer;
    OCat, OItem: TJSONObject;
    CatIdLocal, ItemIdLocal: Integer;

    Cat_IdSite, Cat_QtdMin, Cat_QtdMax, Cat_Modificado, Cat_IdExtra: Integer;
    Cat_Descricao: string;

    It_IdSite, It_Ativo, It_Modificado: Integer;
    It_Nome, It_Desc: string;
    It_Valor: Currency;
  begin
    if (Arr = nil) or (Arr.Count = 0) then
      Exit;

    for I := 0 to Arr.Count - 1 do
    begin
      if not(Arr.Items[I] is TJSONObject) then
        Continue;
      OCat := TJSONObject(Arr.Items[I]);

      // ---- Categoria de extra → pro_adi_personalizado
      Cat_IdSite := GetInt(OCat, 'id'); // id_site
      Cat_Descricao := GetStr(OCat, 'name_adicionais_cat'); // descricao
      Cat_QtdMin := GetInt(OCat, 'minimo', 0); // qtd_minima
      Cat_QtdMax := GetInt(OCat, 'amount', 0); // qtd_maxima
      Cat_Modificado := 1; // modificado_site
      Cat_IdExtra := GetInt(OCat, 'id_cat', 0); // id_extra

      // procura categoria local pelo id_site
      Conexao.SQL.Clear;
      Conexao.SQL.Add
        ('select 0 as zero,id from pro_adi_personalizado where id_site = :id_site');
      Conexao.Parametros('id_site', Cat_IdSite);
      CatIdLocal := Conexao.FieldByName('id');

      if CatIdLocal = 0 then
      begin
        CatIdLocal := Conexao.GerarID('pro_adi_personalizado', 'id');
        Conexao.SQL.Clear;
        Conexao.SQL.Add('insert into pro_adi_personalizado ' +
          '(id, id_produto, descricao, ativo, qtd_minima, qtd_maxima, id_site, modificado_site, id_extra, id_ifood) '
          + 'values (:id, :id_produto, :descricao, :ativo, :qtd_minima, :qtd_maxima, :id_site, :modificado_site, :id_extra, :id_ifood)');
        Conexao.Parametros('id', CatIdLocal);
      end
      else
      begin
        Conexao.SQL.Clear;
        Conexao.SQL.Add('update pro_adi_personalizado set ' +
          'id_produto=:id_produto, descricao=:descricao, ativo=:ativo, ' +
          'qtd_minima=:qtd_minima, qtd_maxima=:qtd_maxima, ' +
          'modificado_site=:modificado_site, id_extra=:id_extra, id_ifood=:id_ifood '
          + 'where id=:id');
        Conexao.Parametros('id', CatIdLocal);
      end;

      AtualizaStatusImportacao('ws_adicionais_cat',Cat_IdSite.ToString);

      Conexao.Parametros('id_produto', ACodProd);
      Conexao.Parametros('descricao', Cat_Descricao);
      Conexao.Parametros('ativo', 1);
      Conexao.Parametros('qtd_minima', Cat_QtdMin);
      Conexao.Parametros('qtd_maxima', Cat_QtdMax);
//      Conexao.Parametros('id_site', Cat_IdSite);
      Conexao.Parametros('modificado_site', 1);
      Conexao.Parametros('id_extra', Cat_IdExtra);
      Conexao.Parametros('id_ifood', ''); // não veio no JSON
      Conexao.ExecuteSQL;

      // ---- Itens da categoria → pro_adi_personalizado_sabores
      if (OCat.Values['itens'] is TJSONArray) then
      begin
        for j := 0 to TJSONArray(OCat.Values['itens']).Count - 1 do
        begin
          if not(TJSONArray(OCat.Values['itens']).Items[j] is TJSONObject) then
            Continue;
          OItem := TJSONObject(TJSONArray(OCat.Values['itens']).Items[j]);

          It_IdSite := GetInt(OItem, 'id_adicionais'); // id_site
          It_Nome := GetStr(OItem, 'nome_adicional'); // nome
          It_Desc := GetStr(OItem, 'descricao'); // descricao
          It_Valor := GetCurr(OItem, 'valor_adicional'); // valor
          It_Ativo := GetInt(OItem, 'status_adicional', 1); // ativo
          It_Modificado := 1; // modificado_site

          // procura item local pelo id_site
          Conexao.SQL.Clear;
          Conexao.SQL.Add
            ('select 0 as zero,id from pro_adi_personalizado_sabores where id_site = :id_site');
          Conexao.Parametros('id_site', It_IdSite);
          ItemIdLocal := Conexao.FieldByName('id');

          AtualizaStatusImportacao('ws_adicionais_itens',It_IdSite.ToString);

          if ItemIdLocal = 0 then
          begin
            ItemIdLocal := Conexao.GerarID
              ('pro_adi_personalizado_sabores', 'id');
            Conexao.SQL.Clear;
            Conexao.SQL.Add('insert into pro_adi_personalizado_sabores ' +
              '(id, id_pro_adi_personalizado, nome, descricao, valor, id_site, ativo, modificado_site, '
              + '  id_ingredientes, quantidade_ingredientes, id_ifood, id_prod_estoque) '
              + 'values (:id, :id_pro_adi_personalizado, :nome, :descricao, :valor, :id_site, :ativo, :modificado_site, '
              + '  :id_ingredientes, :quantidade_ingredientes, :id_ifood, :id_prod_estoque)');
            Conexao.Parametros('id', ItemIdLocal);
          end
          else
          begin
            Conexao.SQL.Clear;
            Conexao.SQL.Add('update pro_adi_personalizado_sabores set ' +
              'id_pro_adi_personalizado=:id_pro_adi_personalizado, nome=:nome, descricao=:descricao, '
              + 'valor=:valor, ativo=:ativo, modificado_site=:modificado_site, '
              + 'id_ingredientes=:id_ingredientes, ' +
              'quantidade_ingredientes=:quantidade_ingredientes, id_ifood=:id_ifood, id_prod_estoque=:id_prod_estoque '
              + 'where id=:id');
            Conexao.Parametros('id', ItemIdLocal);
          end;

          Conexao.Parametros('id_pro_adi_personalizado', CatIdLocal);
          Conexao.Parametros('nome', It_Nome);
          Conexao.Parametros('descricao', It_Desc);
          Conexao.Parametros('valor', It_Valor);

          Conexao.Parametros('ativo', It_Ativo);
          Conexao.Parametros('modificado_site', 1);
          Conexao.Parametros('id_ingredientes', 0);
          Conexao.Parametros('quantidade_ingredientes', 0);
          Conexao.Parametros('id_ifood', '');
          Conexao.Parametros('id_prod_estoque', 0);
          Conexao.ExecuteSQL;
        end;
      end;
    end;
  end;

  procedure UpsertSabores(const ACodProd: Integer; Arr: TJSONArray);
  var
    I: Integer;
    OSabor: TJSONObject;
    NomeSabor: string;
    Descricao: String;
    Status: Integer;
    Valor: Real;
    Foto: String;
    CodSabor: Integer;
    CodigoProduto: Integer;
    Tipo: String;
    Quantidade: Integer;
    ProdutoPizza: Integer;
    CodigoTipo: Integer;
  begin
    if (Arr = nil) or (Arr.Count = 0) then
      Exit;

    for I := 0 to Arr.Count - 1 do
      if Arr.Items[I] is TJSONObject then
      begin
        OSabor := Arr.Items[I] as TJSONObject;
        NomeSabor := GetStr(OSabor, 'sabor');
        Descricao := GetStr(OSabor, 'descricao');
        Foto := GetStr(OSabor, 'url');
        Tipo := GetStr(OSabor, 'tipo');
        Status := GetInt(OSabor, 'ativo');
        Valor := GetCurr(OSabor, 'valor');
        CodSabor := GetInt(OSabor, 'id');
        CodigoProduto := GetInt(OSabor, 'id_itens');
        Quantidade := GetInt(OSabor, 'qtd_sabor');

        // RESOLVE/CRIA sabor
        Conexao.SQL.Clear;
        Conexao.SQL.Add
          ('select * from sabores_completo where upper(nome)=:nome or id_site = :id and id_produto = :prod');
        Conexao.Parametros('nome', UpperCase(NomeSabor));
        Conexao.Parametros('id', CodSabor);
        Conexao.Parametros('prod', ACodProd);
        CodSabor := Conexao.FieldByName('id');

        Conexao.SQL.Add('select * from tipo_sabor where upper(nome) = :tipo');
        Conexao.Parametros('tipo', UpperCase(Tipo));
        CodigoTipo := Conexao.FieldByName('id');

        if CodSabor = 0 then
        begin
          CodSabor := Conexao.GerarID('sabores_completo', 'id');
          Conexao.SQL.Clear;
          Conexao.SQL.Add
            ('insert into sabores_completo (id,id_produto,dt_cadastro,nome,descricao,vl_venda,ativo,id_site,url,id_tipo_sabor)');
          Conexao.SQL.Add
            ('values (:id,:id_produto,curdate(),:nome,:descricao,:vl_venda,:ativo,:id_site,:url,:id_tipo_sabor)');
          Conexao.Parametros('id', CodSabor);
          Conexao.Parametros('id_produto', ACodProd);
          Conexao.Parametros('nome', NomeSabor);
          Conexao.Parametros('descricao', Descricao);
          Conexao.Parametros('vl_venda', Valor);
          Conexao.Parametros('ativo', Status);
          Conexao.Parametros('id_tipo_sabor', CodigoTipo);
          Conexao.Parametros('id_site', GetInt(OSabor, 'id'));
          Conexao.Parametros('url', Foto);
          Conexao.ExecuteSQL;
        end
        else
        begin
          // UPDATE (espelha os campos do insert; mantém dt_cadastro)
          Conexao.SQL.Clear;
          Conexao.SQL.Add('update sabores_completo');
          Conexao.SQL.Add('   set id_produto = :id_produto,');
          Conexao.SQL.Add('       nome       = :nome,');
          Conexao.SQL.Add('       descricao  = :descricao,');
          Conexao.SQL.Add('       vl_venda   = :vl_venda,');
          Conexao.SQL.Add('       ativo      = :ativo,');
          Conexao.SQL.Add('       id_site    = :id_site,');
          Conexao.SQL.Add(' id_tipo_sabor    = :id_tipo_sabor,');
          Conexao.SQL.Add('       url        = :url');
          Conexao.SQL.Add(' where id         = :id');
          Conexao.Parametros('id_produto', ACodProd);
          Conexao.Parametros('id_tipo_sabor', CodigoTipo);
          Conexao.Parametros('nome', NomeSabor);
          Conexao.Parametros('descricao', Descricao);
          Conexao.Parametros('vl_venda', Valor);
          Conexao.Parametros('ativo', Status);
          Conexao.Parametros('id_site', GetInt(OSabor, 'id'));
          Conexao.Parametros('url', Foto);
          Conexao.Parametros('id', CodSabor);
          Conexao.ExecuteSQL;

        end;
        AtualizaStatusImportacao('ws_sabores',GetStr(OSabor, 'id'));

        Conexao.SQL.Add
          ('select * from produto_pizza where codigo_produto = :prod');
        Conexao.Parametros('prod', ACodProd);
        ProdutoPizza := Conexao.FieldByName('codigo');

        if ProdutoPizza = 0 then
        begin
          ProdutoPizza := Conexao.GerarID('produto_pizza', 'codigo');
          Conexao.SQL.Add
            ('insert into produto_pizza (codigo,codigo_produto,quantidade_sabores,id_site)');
          Conexao.SQL.Add
            ('values (:codigo,:codigo_produto,:quantidade_sabores,:id_site)');
          Conexao.Parametros('codigo', ProdutoPizza);
          Conexao.Parametros('codigo_produto', ACodProd);
          Conexao.Parametros('qtd_sabor', GetInt(OSabor, 'id'));
          Conexao.Parametros('id_site', GetInt(OSabor, 'id'));
          Conexao.ExecuteSQL;
        end;

        Conexao.SQL.Add('update produto set pizza = 1 where codigo = :codigo');
        Conexao.Parametros('codigo', ACodProd);
        Conexao.ExecuteSQL;

      end;
  end;

var
  ArrExtras, ArrSabores: TJSONArray;
begin
  // Lê campos do JSON do produto
  IdSite := GetStr(Produto, 'id');
  Nome := GetStr(Produto, 'nome_item');
  Desc := GetStr(Produto, 'descricao_item');
  url := GetStr(Produto, 'img_ifood');
  Valor := GetCurr(Produto, 'preco_item');
  PromoValor := GetCurr(Produto, 'promo_valor');
  FidelidadeValor := GetCurr(Produto, 'fidelidade_valor');
  Ativo := GetBool(Produto, 'disponivel');
  Novidade := GetBool(Produto, 'novidade');
  VemBuscar := GetBool(Produto, 'vembuscar');
  Delivery := GetBool(Produto, 'delivery');
  Tipos := GetStr(Produto, 'tipos');
  Ordem := GetInt(Produto, 'posicao');

  // Via categoria carregada previamente
  CodigoCategoria := GetInt(Produto, '__codigo_categoria');

  // Descobre se já existe produto
  Conexao.SQL.Clear;
  Conexao.SQL.Add
    ('select * from produto where id_site = :id or upper(nome_produto) like :nome');
  Conexao.Parametros('id', IdSite);
  Conexao.Parametros('nome', '%' + UpperCase(Nome) + '%');
  CodigoProduto := Conexao.FieldByName('codigo');

  if CodigoProduto = 0 then
  begin
    CodigoProduto := Conexao.GerarID('produto', 'codigo');
    Conexao.SQL.Clear;
    Conexao.SQL.Add
      ('insert into produto (data_cadastro,codigo, nome_produto, descricao, id_site, codigo_grupo, position, valor_venda, ativo, valor_desconto, percentual_desconto, fidelidade, novidade, vembuscar, delivery, tiposite,foto_ifood)');
    Conexao.SQL.Add
      ('values (curdate(),:codigo, :nome_produto, :descricao, :id_site, :codigo_grupo, :ordem, :valor, :ativo, :promo_valor, :percentual_desconto, :fidelidade, :novidade, :vembuscar, :delivery, :tiposite, :url)');
    // Se existir tabela de relação categoria x produto:
    Conexao.Parametros('codigo', CodigoProduto);
    Conexao.Parametros('nome_produto', Nome);
    Conexao.Parametros('descricao', Desc);
    Conexao.Parametros('id_site', IdSite);
    Conexao.Parametros('codigo_grupo', CodigoCategoria);
    Conexao.Parametros('ordem', Ordem);
    Conexao.Parametros('valor', Valor);
    Conexao.Parametros('ativo', Ord(Ativo));
    Conexao.Parametros('promo_valor', PromoValor);
    Conexao.Parametros('percentual_desconto',
      GetCurr(Produto, 'promo_percentual')); // se vier percentual
    Conexao.Parametros('fidelidade', FidelidadeValor);
    Conexao.Parametros('novidade', Ord(Novidade));
    Conexao.Parametros('vembuscar', Ord(VemBuscar));
    Conexao.Parametros('delivery', Ord(Delivery));
    Conexao.Parametros('tiposite', Tipos);
    Conexao.Parametros('url', url);
    Conexao.ExecuteSQL;

  end
  else
  begin
    Conexao.SQL.Clear;
    Conexao.SQL.Add
      ('update produto set nome_produto=:nome_produto, descricao=:descricao, codigo_grupo=:codigo_grupo, position=:ordem,');
    Conexao.SQL.Add
      ('valor_venda=:valor, ativo=:ativo, valor_desconto=:promo_valor, percentual_desconto=:percentual_desconto,');
    Conexao.SQL.Add
      ('fidelidade=:fidelidade, novidade=:novidade,foto_ifood=:url, vembuscar=:vembuscar, delivery=:delivery, tiposite=:tiposite, id_site=:id_site');
    Conexao.SQL.Add('where codigo=:codigo');

    Conexao.Parametros('nome_produto', Nome);
    Conexao.Parametros('descricao', Desc);
    Conexao.Parametros('codigo_grupo', CodigoCategoria);
    Conexao.Parametros('ordem', Ordem);
    Conexao.Parametros('valor', Valor);
    Conexao.Parametros('ativo', Ord(Ativo));
    Conexao.Parametros('promo_valor', PromoValor);
    Conexao.Parametros('percentual_desconto',
      GetCurr(Produto, 'promo_percentual'));
    Conexao.Parametros('fidelidade', FidelidadeValor);
    Conexao.Parametros('novidade', Ord(Novidade));
    Conexao.Parametros('vembuscar', Ord(VemBuscar));
    Conexao.Parametros('delivery', Ord(Delivery));
    Conexao.Parametros('tiposite', Tipos);
    Conexao.Parametros('id_site', IdSite);
    Conexao.Parametros('codigo', CodigoProduto);
    Conexao.Parametros('url', url);
    Conexao.ExecuteSQL;

  end;
  AtualizaStatusImportacao('ws_itens',IdSite);

  // EXTRAS
  if Produto.Values['extras'] is TJSONArray then
  begin
    ArrExtras := Produto.Values['extras'] as TJSONArray;
    UpsertExtras(CodigoProduto, ArrExtras);
  end;

  // SABORES
  if Produto.Values['sabores'] is TJSONArray then
  begin
    ArrSabores := Produto.Values['sabores'] as TJSONArray;
    UpsertSabores(CodigoProduto, ArrSabores);
  end;
end;

end.
